using System.Collections;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    private WeaponStateMachine _machine;
    private WeaponContext _context;
    private WeaponInput _input = new WeaponInput();
    private WeaponFlag _flag = new WeaponFlag();

    private Vector3 weaponLocalOffset = new Vector3(0.6f, 0, 0);

    private WeaponModel _model;
    public Transform FirePosition;
    public Transform WeaponAnchor;

    private Vector3 _baseLocalPos;
    private Quaternion _baseLocalRot;

    private WeaponData _weaponData;
    public WeaponData WeaponData
    {
        get { return _weaponData; }
        set
        {
            _weaponData = value;
            SetWeapon();
        }
    }

    public WeaponData _baseData;

    private void Awake()
    {
        _baseLocalPos = transform.localPosition;
        _baseLocalRot = transform.localRotation;
        SetContext();

        _machine = new WeaponStateMachine(_context);
    }

    private void Start()
    {
        SetWeapon();
        _machine.ChangeState(WeaponStateType.Idle);
    }

    private void Update()
    {
        _machine.Update(Time.deltaTime);
    }

    public void TryFire()
    {
        if (_weaponData == null) { return; }
        Debug.Log($"{this.gameObject.name} : 사격 시도");
        _input.AttackPressed = true;
    }

    void SetWeapon()
    {
        if (_weaponData == null) { _weaponData = _baseData; }

        if (_model != null)
        { Destroy(_model); } // 나중에 아이템DB 같은데에 반환하기

        if (_weaponData.Model != null)
        {
            // 나중에 아이템DB 같은데에서 가져오기
            _model = Instantiate(_weaponData.Model, transform);
            _model.transform.localPosition = weaponLocalOffset;
            _model.transform.rotation = transform.rotation;
        }

        FirePosition = _model?.FirePosition;

        SetContext();
    }

    private void SetContext()
    { 
        _context = _context == null ? new WeaponContext() : _context;
        _context.WeaponBaseLocalPos = _baseLocalPos;
        _context.WeaponBaseLocalRot = _baseLocalRot;
        _context.WeaponPos = transform;

        _context.WeaponInput = _input;
        _context.WeaponFlag = _flag;
        _context.WeaponAchorPos = WeaponAnchor;

        // 데이터 초기화
        _context.WeaponData = _weaponData == null ? _baseData : _weaponData;
        _context.FirePosition = FirePosition == null ? transform : FirePosition;
        
        // 탄약 초기화
        _context.CurrentCapacity = _context.WeaponData == null ? 0 : _context.WeaponData.MaxCapacity;
        _context.AmmoRemaining = _context.WeaponData == null ? 0 : _context.WeaponData.MaxAmmo;
    }
}