using UnityEngine;
using UnityEngine.Rendering;

public class WeaponIdleStateLogic : StateLogic<WeaponContext>
{
    public WeaponIdleStateLogic(WeaponContext context) : base(context) { }

    public override void UpdateStateLogic(float deltaTime)
    {
        _context.WeaponAchorPos.rotation = Quaternion.Euler(new Vector3(0,0,300f));
    }

    public override void Clear() { }
}

public class WeaponAimStateLogic : StateLogic<WeaponContext>
{
    float _time = 0f;

    public WeaponAimStateLogic(WeaponContext context) : base(context) { }

    public override void UpdateStateLogic(float deltaTime)
    {
        if (_context.WeaponFlag.IsAimComplete)
        {
            _time = 0;
            return;
        }

        // WeaponAchor의 회전을 타겟에 맞춤
        float dest = 0f; // 임시 회전값
        dest = Mathf.Lerp(_context.WeaponAchorPos.eulerAngles.z, dest, 1);
        _context.WeaponAchorPos.rotation = Quaternion.Euler(new Vector3(0, 0, dest));

        _time += deltaTime;
        _context.WeaponFlag.IsAimComplete = _time >= _context.WeaponData.MaxAimTime;
    }

    public override void Clear() { _time = 0f; }
}

public class WeaponFireStateLogic : StateLogic<WeaponContext>
{
    public WeaponFireStateLogic(WeaponContext context) : base(context) { }

    public override void UpdateStateLogic(float deltaTime)
    {
        // 총알 생성 요청후 
        _context.WeaponFlag.IsFireComplete = true;
    }

    public override void Clear() { }
}

public class WeaponRecoilStateLogic : StateLogic<WeaponContext>
{
    float _elapsedTime = 0f;

    public WeaponRecoilStateLogic(WeaponContext context) : base(context) { }

    public override void UpdateStateLogic(float deltaTime)
    {
        float fireRate = 1f / _context.WeaponData.FireRate;
        float speed = (_elapsedTime / fireRate) * 0.5f;

        Vector3 localPos = _context.WeaponPos.localPosition;
        Vector3 baseLocalPos = _context.WeaponBaseLocalPos;

        float distance = Mathf.Abs(baseLocalPos.x - localPos.x);
        float kickBack = _context.WeaponData.RecoilData.KickBack;

        // 무기의 로컬 포지션이 반동 킥백만큼 움직이지 않았을때
        if (distance <= kickBack)
        {
            float kickSpeed = (_elapsedTime / fireRate) * 0.5f;
            _context.WeaponPos.localPosition = new Vector3(Mathf.Lerp(localPos.x, kickBack, speed), localPos.y, localPos.z);
        }
        // 무기의 로컬 포지션이 반동 킥백만큼 움직였을때
        else
        {
            _context.WeaponPos.localPosition = Vector3.Lerp(localPos, baseLocalPos, speed);
        }

        _elapsedTime += deltaTime;
        _context.WeaponFlag.IsRecoilComplete = _elapsedTime >= 1f / _context.WeaponData.FireRate;
    }

    public override void Clear() { _elapsedTime = 0f; }
}

public class WeaponReloadStateLogic : StateLogic<WeaponContext>
{
    float _currentReloadTime = 0f;

    public WeaponReloadStateLogic(WeaponContext context) : base(context) { }

    public override void UpdateStateLogic(float deltaTime)
    {
        _currentReloadTime += deltaTime;
        _context.WeaponFlag.IsReloadComplete = _currentReloadTime >= _context.WeaponData.MaxReloadDuration;
    }

    public override void Clear() { _currentReloadTime = 0f; }
}
