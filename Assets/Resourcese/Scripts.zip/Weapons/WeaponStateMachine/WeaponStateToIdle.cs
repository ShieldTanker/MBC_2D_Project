﻿public class WeaponStateToIdle : StateTransition<WeaponStateType, WeaponContext>
{
    float _time = 0f;
    public WeaponStateToIdle(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        // 발사 입력이 없고 재장전 상태가 아닐때
        if (!_context.IsFireInput && !_context.IsReloading)
        {
            _time += deltaTime;
            if (_time >= 2f) { return true; }
        }
        else
        { _time = 0f; }

        return false;
    }
}

public class WeaponStateToAim : StateTransition<WeaponStateType, WeaponContext>
{
    private float _time = 0f;

    public WeaponStateToAim(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        // 발사 입력이 있고 리로딩 상태가 아닐때
        if (!_context.IsFireInput && !_context.IsReloading)
        {
            _time += deltaTime;
            if (_time >= 2f) { return true; }
        }
        else
        { _time = 0f; }

        return false;
    }
}

public class WeaponStateToFire : StateTransition<WeaponStateType, WeaponContext>
{
    public WeaponStateToFire(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        if (_context.IsFireInput && !_context.IsReloading) { return true; }

        return false;
    }
}

public class WeaponStateToRecoil : StateTransition<WeaponStateType, WeaponContext>
{
    public WeaponStateToRecoil(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        if (_context.IsFireInput) { return true; }

        return false;
    }
}

public class WeaponStateToReload : StateTransition<WeaponStateType, WeaponContext>
{
    public WeaponStateToReload(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        // 나중에 WasPressedFrame으로 바꾸기
        if (_context.IsReloading) { return true; }

        return false;
    }
}

public class WeaponStateToHolding : StateTransition<WeaponStateType, WeaponContext>
{
    public WeaponStateToHolding(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    float _time = 0f;

    public override bool CheckStateTransit(float deltaTime)
    {
        if (_context.IsFireInput)
        {
            _time += deltaTime;
            if( _time > 2f) { return true; }
        }
        else { _time = 0f; }

        return false;
    }
}