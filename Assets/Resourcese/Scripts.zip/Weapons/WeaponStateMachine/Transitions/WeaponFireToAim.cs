public class WeaponFireToAim : StateTransition<WeaponStateType, WeaponContext>
{
    public WeaponFireToAim(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        WeaponInput input = _context.WeaponInput;
        // 현재 장탄수가 0이하이면 Empty로 이동
        return !input.AttackPressed && !input.AttackSequenceStarted;
    }

    public override void Clear() { }
}
