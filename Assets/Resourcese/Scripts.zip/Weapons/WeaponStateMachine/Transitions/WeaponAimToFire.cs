
/// <summary>
/// 조준(Aim) → 발사(Fire)
/// </summary>
public class WeaponAimToFire : StateTransition<WeaponStateType, WeaponContext>
{
    public WeaponAimToFire(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        if (_context.IsInterrupted) return false;
        if (!_context.WeaponFlag.IsAimComplete) return false;
        if (!_context.WeaponFlag.CanFire) return false;

        return CheckAttack();
    }

    private bool CheckAttack()
    {
        WeaponInput input = _context.WeaponInput;
        return input.AttackPressed || input.AttackSequenceStarted;
    }

    public override void Clear() { }
}
