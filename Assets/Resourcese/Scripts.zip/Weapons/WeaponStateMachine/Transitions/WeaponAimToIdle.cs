﻿
/// <summary>
/// 조준(Aim) → 아이들(Idle)
/// </summary>
public class WeaponAimToIdle : StateTransition<WeaponStateType, WeaponContext>
{
    public WeaponAimToIdle(WeaponContext context, WeaponStateType stateType)
        : base(context, stateType) { }

    public override bool CheckStateTransit(float deltaTime)
    {
        if (_context.IsInterrupted) return true;

        return _context.WeaponFlag.IsAimCanceled;
    }

    public override void Clear() { }
}
