﻿using System.Collections.Generic;
using UnityEngine;

// 사격 상태
public class WeaponFireState : State<WeaponStateType, WeaponContext>
{
    WeaponContext _context;
    

    float _rateTime = 0f;

    public WeaponFireState(WeaponStateMachine machine,
        List<StateTransition<WeaponStateType, WeaponContext>> transitions)
    {
        _machine = machine;
        _transitions = transitions;

        _context = _machine.Context;
    }

    public override void StateEnter()
    {
        base.StateEnter();
        _context.WeaponFlag.IsFireComplete = false;
        _rateTime = 0f;

        if (_context.WeaponData == null || _context.CurrentCapacity <= 0)
        {
            _context.WeaponFlag.IsFireComplete = true;
            return;
        }
    }

    public override void StateUpdate(float deltaTime)
    {
        _context.WeaponFlag.CanFire =
            _context.WeaponData != null && _context.WeaponData.BulletModel != null &&
            _context.CurrentCapacity > 0; // 현재 탄약이 0 이상, 

        _rateTime += deltaTime;

        // RecoilExample(); // 반동값으로 반동
        TryFire(); // 발사 입력

        base.StateUpdate(deltaTime);
    }

    public override void StateExit()
    {
        base.StateExit();

        _machine.Context.WeaponFlag.IsFireComplete = false;
        _rateTime = 0f;
    }

    void TryFire()
    {
        // 공격키가 안눌리고 시퀀스도 시작하지 않으면 리턴
        if (!_context.WeaponInput.AttackPressed && !_context.WeaponInput.AttackSequenceStarted) return;
        // 발사 시간이 안되면 리턴
        if (_rateTime < 60f / _context.WeaponData.FireRate) return;

        WeaponInput input = _context.WeaponInput;
        // 발사 입력후 첫발(단발)
        if (input.AttackSequenceStarted)
        {
            input.AttackSequenceStarted = false;
            Fire();
            if (_context.WeaponData.FireMode == WeaponFireMode.SemiAuto)
                _context.WeaponInput.AttackPressed = false;
            return;
        }

        if (!_context.WeaponInput.AttackPressed) return;

        // 연사
        if (_context.WeaponData.FireMode == WeaponFireMode.FullAuto)
        {
            Fire();
            return;
        }
    }

    void Fire()
    {
        if (_context.WeaponData.BulletModel != null && _context.FirePosition != null)
        {
            // 총알 생성, 나중에 오브젝트풀로 바꿀것
            GameObject.Instantiate(
                _context.WeaponData.BulletModel, _context.FirePosition.position, _context.FirePosition.rotation);

            _context.CurrentCapacity--;

        }
        // 발사 시간 초기화
        _rateTime = 0f;

        // 플래그 설정
        _context.WeaponFlag.CanFire = _context.CurrentCapacity > 0;

        // Recoil();
        FireRecoilTest();
    }

    void Recoil()
    {
        RecoilData recoilData = _context.WeaponData.RecoilData;
        float fireRate = 60 / _context.WeaponData.FireRate;

        if (recoilData == null)
        {
            _context.WeaponFlag.IsRecoilComplete = true;
            return;
        }

        float recoilDuration = Mathf.Max(fireRate, 0.0001f);
        float normalizedTime = Mathf.Clamp01(_rateTime / recoilDuration);

        Vector3 basePosition = _context.WeaponBaseLocalPos;
        Quaternion baseRotation = _context.WeaponBaseLocalRot;

        Vector3 recoilPosition = basePosition;
        Quaternion recoilRotation = baseRotation;

        // 반동 방향은 무기의 로컬 -X 방향
        recoilPosition.x -= recoilData.KickBack;

        // Pitch 반동
        recoilRotation *= Quaternion.Euler(0f, 0f, recoilData.KickPitchAngle);

        if (_rateTime >= recoilDuration)
        {
            _context.WeaponPos.localPosition = basePosition;
            _context.WeaponPos.localRotation = baseRotation;

            _context.WeaponFlag.IsRecoilComplete = true;
        }
    }

    void RecoilExample()
    {
        Transform transform = _context.WeaponPos;
        transform.localPosition = Vector3.SmoothDamp
            (transform.localPosition, _context.WeaponBaseLocalPos, ref _context.recoilVelocity, 0.5f); //앞뒤반동
        
        // recoilAngle = Mathf.SmoothDamp(recoilAngle, 0, ref recoilRotSmoothDampVelocity, recoilRotationSettleTime); //상하반동
        // transform.localEulerAngles += Vector3.left * recoilAngle;
    }

    void FireRecoilTest()
    {
        float kickX = _context.WeaponData.RecoilData.KickBack;
        float kickY = _context.WeaponData.RecoilData.KickUp;
        Vector2 recoil = Vector2.right * Random.Range(kickX, kickY);
        _context.WeaponPos.localPosition -= new Vector3(recoil.x, recoil.y, 0);

        //recoilAngle += Random.Range(recoilAngleMinMax.x, recoilAngleMinMax.y);
        //recoilAngle = Mathf.Clamp(recoilAngle, 0, 40);
    }
}