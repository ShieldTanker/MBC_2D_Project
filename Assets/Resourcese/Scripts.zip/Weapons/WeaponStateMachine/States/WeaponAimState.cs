﻿using System.Collections.Generic;
using UnityEngine;

// 에임 상태
public class WeaponAimState : State<WeaponStateType, WeaponContext>
{
    private WeaponContext _context;
    private WeaponFlag _flag;
    private WeaponInput _input;

    private float _aimTime;
    private float aimToIdleTimer;

    public WeaponAimState(WeaponStateMachine machine,
        List<StateTransition<WeaponStateType, WeaponContext>> transitions)
    {
        _machine = machine;
        _transitions = transitions;

        _context = _machine.Context;
        _flag = _context.WeaponFlag;
        _input = _context.WeaponInput;
    }

    public override void StateEnter()
    {
        base.StateEnter();
        _machine.Context.WeaponAnchorPos.rotation = Quaternion.Euler(new Vector3(0, 0, 0f));

        aimToIdleTimer = 0f;

        if (!_flag.IsAimComplete)
            _aimTime = 0f;
    }

    public override void StateUpdate(float deltaTime)
    {
        // 에임 완료 상태가 아니면
        if (!_flag.IsAimComplete)
        {
            _aimTime += deltaTime;
            _flag.IsAimComplete = _aimTime >= _context.WeaponData.MaxAimTime;
        }

        // 아이들 상태전환 타이머
        if (_input.AttackPressed || _input.InteractionPressed) aimToIdleTimer = 0f;
        else
        {
            aimToIdleTimer += deltaTime;
            _flag.IsAimCanceled = aimToIdleTimer >= _context.WeaponData.MaxAimTime;
            if (_flag.IsAimCanceled)
            {
                _aimTime = 0f;
                _flag.IsAimComplete = false;
            }
        }        

        base.StateUpdate(deltaTime);
    }

    public override void StateExit()
    {
        base.StateExit();
        aimToIdleTimer = 0f;

        if (!_flag.IsAimComplete)
            _aimTime = 0f;
    }
}